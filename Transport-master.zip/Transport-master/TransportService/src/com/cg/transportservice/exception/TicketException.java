package com.cg.transportservice.exception;

public class TicketException extends Exception {

	public TicketException() {
		// TODO Auto-generated constructor stub
	}

	public TicketException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public TicketException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public TicketException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public TicketException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
